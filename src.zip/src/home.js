import React from "react";
import {
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  Image,
  ImageBackground,
  View,
} from "react-native";
// import UserList from "./user-list";
import Header from "./header";
// import sanityClient from "";
// import BackButton from "./back-button";
// import User from "./user";
// import {Asset} from 'expo-asset';

// const imageURI = Asset.fromModule(require('./arrow.png')).uri;

// const image = require("./assets/aoeu.jpg");

class Home extends React.Component {
  state = {
    user: {},
    loading: true,
  };

  componentDidMount() {
    // TODO: get users
    this.getUser();
  }

  async getUser() {
    // sanityClient
    //   .fetch(
    //     `*[ _type == "user" && emailAddress.current == "dwight@viamaven.com"]`
    //   )
    //   .then((data) => {
    //     console.log(data);
    //     this.setState({ user: data[0], loading: false });
    //     console.log(this.state.user);
    //   })
    //   .catch((err) => console.error(err));
    // const res = await fetch("https://randomuser.me/api/?results=20");
    // const { results} = await res.json();
    // // console.log(results)
    // this.setState({users: [...results], loading: false});
  }

  render() {
    return (
      <ScrollView
        noSpacer={true}
        noScroll={true}
        style={styles.container}
        showVerticalSCrollIndicator={false}
        showHorizontalScrollIndicator={false}
      >
        {!this.state.loading ? (
          <ActivityIndicator
            style={[styles.centering, styles.gray]}
            color="#5d38aa"
            size="large"
          />
        ) : (
          <View>
            <Header title={"Spidy"} />
            <View id="image">
              <Image source={require("./arrow.png")} style={styles.image} />
            </View>
            {/* <User /> */}
          </View>
        )}
      </ScrollView>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    width: 375,
    height: 812,
    // top: '50px',
  },
  centering: {
    alignItems: "center",
    justifyContent: "center",
    padding: 8,
    height: "100vh",
  },
  image: {
    width: 50,
    height: 50,
    marginRight: 20,
    // boxShadow: "0px 1px 2px 0px rgba(0,0,0,0.1)",
    // boxShadow: "10px 10px 17px -12px rgba(0,0,0,0.75)",
  },
});

export default Home;
